YouTube video to MP3 converter

1.) Go to https://rapidapi.com/ytjar/api/youtube-mp36 and get your free API key by choosing the freemium subscription plan

2.) Replace the "process.env.API_KEY" and "process.env.API_HOST" variables in the index.js file with your very own API key and API host

3.) Enjoy!
